local Players = game:GetService("Players")
local ReSt = game:GetService("ReplicatedStorage")
local RS = game:GetService("RunService")
local TS = game:GetService("TweenService")
local CG = game:GetService("CoreGui")

local Plr = Players.LocalPlayer
local Char = Plr.Character or Plr.CharacterAdded:Wait()
local humanoid = Char:WaitForChild("Humanoid")
local Camera = workspace.CurrentCamera
local CanMove = true

local function setup_blackout()
    local bo_time = 7
    local audios = {
        { id = "rbxassetid://176554627",  name = "hardcore_heartbeat",  looped = true,  PlaybackSpeed = 1 },
        { id = "rbxassetid://8316701225", name = "lights_shutdown",     looped = false, PlaybackSpeed = 1 },
        { id = "rbxassetid://876800936",  name = "lights_turnon",       looped = false, PlaybackSpeed = 1 },
        { id = "rbxassetid://8991674830", name = "jumpscare_blackout",  looped = false, PlaybackSpeed = 1 },
    }

    for _, audio in pairs(audios) do
        local sound = Instance.new("Sound")
        sound.SoundId = audio.id
        sound.Name = audio.name
        sound.Looped = audio.looped
        sound.PlaybackSpeed = audio.PlaybackSpeed
        if sound.Name == "jumpscare_blackout" then
            local pitchshift = Instance.new("PitchShiftSoundEffect")
            pitchshift.Octave = 0.5
            pitchshift.Parent = sound
        elseif sound.Name == "lights_turnon" then
            local reverb = Instance.new("ReverbSoundEffect")
            reverb.WetLevel = -40
            reverb.Parent = sound
        end
        sound.Parent = workspace
    end

    game.ReplicatedStorage.GameData.LatestRoom.Changed:Wait()
    _G.Blackout = "unsafe"

    local spawn_waittime = 1
    task.wait(spawn_waittime)

    local ScreenGui = Instance.new("ScreenGui")
    ScreenGui.ResetOnSpawn = false
    ScreenGui.IgnoreGuiInset = true
    ScreenGui.DisplayOrder = 100

    local Frame = Instance.new("Frame")
    local ImageLabel = Instance.new("ImageLabel")

    ScreenGui.Parent = CG
    Frame.Parent = ScreenGui
    Frame.BackgroundColor3 = Color3.new(0, 0, 0)
    Frame.BackgroundTransparency = 0
    Frame.Size = UDim2.new(1, 0, 1, 0)
    Frame.Position = UDim2.new(0, 0, 0, 0)
    Frame.BorderSizePixel = 0

    ImageLabel.Parent = Frame
    ImageLabel.Size = UDim2.new(1.2, 0, 1, 0)
    ImageLabel.Position = UDim2.new(-0.1, 0, 0, 0)
    ImageLabel.Image = "rbxassetid://140286191775781"
    ImageLabel.ImageTransparency = 1
    ImageLabel.BackgroundTransparency = 1
    ImageLabel.Visible = false
    ImageLabel.ScaleType = Enum.ScaleType.Stretch

    local lightsdownsnd = workspace:FindFirstChild("lights_shutdown")
    if lightsdownsnd then
        lightsdownsnd:Play()
    end

    task.wait(1.5)
    CanMove = false

    local heartbeatsnd = workspace:FindFirstChild("hardcore_heartbeat")
    local jumpscare_active = false

    local steppedConn
    steppedConn = RS.Stepped:Connect(function()
        if not CanMove
            and not jumpscare_active
            and (humanoid.MoveDirection.Magnitude > 0)
        then
            jumpscare_active = true
            humanoid.WalkSpeed = 0
            humanoid.JumpPower = 0

            ImageLabel.Visible = true
            ImageLabel.ImageTransparency = 0
            ImageLabel.Size = UDim2.new(1.2, 0, 1, 0)
            ImageLabel.Position = UDim2.new(-0.1, 0, 0, 0)

            local killsndob = workspace:FindFirstChild("jumpscare_blackout")
            if killsndob then killsndob:Play() end

            task.wait(1.9)

            TS:Create(ImageLabel, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
                Size = UDim2.new(4.8, 0, 4.4, 0),
                Position = UDim2.new(-1.9, 0, -1.7, 0),
            }):Play()
            task.wait(0.1)
            -- total on-screen before death: 1.9 + 0.1 = 2.0s exactly

            -- destroy the visual right away -- it was staying up an extra 1.5s
            -- because the destroy call was down after the audio cleanup wait below
            pcall(function() ScreenGui:Destroy() end)
            if steppedConn then steppedConn:Disconnect() end

            local msg = {"Oh... hello.", "Not this place again...", "Nevermind that... What'd you die to?", "Oh... the dark.", "It doesn't like when you move through it, so...", "Maybe you could call it Blackout?", "Anyways, I hope you don't mind trying again. It would be helpful."}
            local color = "Yellow"
            humanoid.Health = 0
            pcall(function() SetDeathCause("Blackout") end)
            local hintOk, hintErr = pcall(firesignal, game:GetService("ReplicatedStorage").EntityInfo.DeathHint.OnClientEvent, msg, color)
            if not hintOk then
                warn("[Mayhem/Blackout] DeathHint firesignal failed: " .. tostring(hintErr))
            end

            if heartbeatsnd then heartbeatsnd:Stop() end
            task.wait(1.5)
            if killsndob then
                task.wait(2)
                killsndob:Destroy()
            end
        end
    end)

    if heartbeatsnd then
        heartbeatsnd:Play()
    end

    task.wait(bo_time - 1.5)
    CanMove = true

    local lightsonsnd = workspace:FindFirstChild("lights_turnon")
    if lightsonsnd then
        if heartbeatsnd then heartbeatsnd:Stop() end
        lightsonsnd:Play()
    end

    if not jumpscare_active then
        pcall(function() ScreenGui:Destroy() end)
        if steppedConn then steppedConn:Disconnect() end
    end

    _G.Blackout = "safe"
end

setup_blackout()
